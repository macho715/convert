# /kpi-dash
Exec: run pytest-cov & collect gates; print summary table
