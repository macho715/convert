# Cursor Auto-Setup Pack (Cursor-only)

Unzip at your project root and commit.
