# AGI TR6 Excel+VBA+Python Automation Pack (LTSC 2021)

## What you get
- `AGI_TR6_VBA_Enhanced_AUTOMATION.xlsx` : 원본 + LOG/SETTINGS 시트 추가(매크로 없음)
- `AGI_TR_AutomationPack.bas` : VBA 모듈(매크로 전체)
- `ThisWorkbook_EventCode.txt` : 이벤트(Workbook_Open/BeforeClose) 코드
- `agi_tr_runner.py` : Python Runner(스케줄 업데이트/검증/간트 재생성)
- `requirements.txt`, `run_local.bat`

## Install (Excel)
1) `AGI_TR6_VBA_Enhanced_AUTOMATION.xlsx` 열기 → `다른 이름으로 저장` → **.xlsm**
2) Alt+F11 → VBA Editor → Insert > Module → `AGI_TR_AutomationPack.bas` Import
3) ThisWorkbook 더블클릭 → `ThisWorkbook_EventCode.txt` 내용 붙여넣기
4) Control_Panel에서 버튼(도형) 만들고 아래 매크로 연결:
   - RefreshAll / UpdateAllDates / GenerateDailyBriefing / ExportToCSV / BackupWorkbook / ExportVisibleSheetsToPDF / RunPythonUpdate / ValidateScheduleData

## Install (Python)
```bat
python -m venv .venv
.\.venv\Scripts\activate
pip install -r requirements.txt
```

## Run python manually
```bat
.\.venv\Scripts\activate
python agi_tr_runner.py --in "AGI_TR6_VBA_Enhanced_AUTOMATION.xlsx" --out ".\out" --mode update
```

## Settings sheet
- `PYTHON_EXE` : `py` 또는 python.exe 경로
- `PY_SCRIPT` : agi_tr_runner.py 절대경로(회사PC 기준)
- `OUT_DIR` : 결과 저장 폴더
- `BACKUP_DIR` : 백업 폴더
- `LOG_FILE` : 로그 파일
