def main() -> str:
    return "it works"
