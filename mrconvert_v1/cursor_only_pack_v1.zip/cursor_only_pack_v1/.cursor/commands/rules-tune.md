# /rules-tune
Exec: open .cursor/rules and update thresholds; commit with "chore(rules): tune gates"
