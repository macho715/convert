# /automate pre-commit+ci
Exec: tools/init_settings.py --apply-precommit --apply-ci --python=3.13
Output: .pre-commit-config.yaml, .github/workflows/ci.yml ready
