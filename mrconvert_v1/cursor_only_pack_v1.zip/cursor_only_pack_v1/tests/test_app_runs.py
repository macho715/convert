from src.core.app import main

def test_app_runs():
    assert main() == "it works"
