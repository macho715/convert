# AGI_TR6 READY PACK (Excel LTSC 2021 + VBA + Python)

## 구성
- AGI_TR6_VBA_Enhanced_AUTOMATION.xlsx : 베이스 워크북(매크로 없음)
- AGI_TR6_VBA_Enhanced_AUTOMATION_READY.xlsm : (설치 후 생성) 매크로 포함 워크북
- AGI_TR_AutomationPack.bas : VBA 전체 모듈(버튼/로그/검증/내보내기/파이썬 실행)
- ThisWorkbook_EventCode.txt : Workbook_Open/BeforeClose 이벤트 코드
- ONE_CLICK_INSTALL.bat / .vbs : VBA 자동 주입 + XLSM 생성(원클릭)
- agi_tr_runner.py : Python 업데이트/검증 엔진
- tr6_pipeline.py : Python 리포트 엔진
- requirements.txt / requirements_tr6.txt : 라이브러리 목록
- run_local.bat : Python 로컬 실행 예시

## 1) 가장 빠른 사용(권장)
1. 이 폴더에서 `ONE_CLICK_INSTALL.bat` 실행
2. 생성된 `AGI_TR6_VBA_Enhanced_AUTOMATION_READY.xlsm` 열기
3. 상단 보안경고가 뜨면 **콘텐츠 사용(Enable Content)** 클릭
4. `Control_Panel` 시트 버튼 실행

> 설치가 실패하면 아래 옵션을 켜야 합니다.
Excel > 파일 > 옵션 > 보안 센터 > 보안 센터 설정 > 매크로 설정 >
✅ “VBA 프로젝트 개체 모델에 대한 신뢰할 수 있는 액세스”

## 2) Python(선택)
### venv
```bat
python -m venv .venv
.\.venv\Scripts\pip install -r requirements.txt
```

### 실행
```bat
.\.venv\Scripts\python agi_tr_runner.py --in "AGI_TR6_VBA_Enhanced_AUTOMATION_READY.xlsm" --out ".\out" --mode update
.\.venv\Scripts\python tr6_pipeline.py --in "AGI_TR6_VBA_Enhanced_TEMPLATE.xlsx" --out ".\out" --log ".\out\tr6_ops.log"
```

## 3) 테스트
- Python: 위 명령 실행 시 out 폴더에 *_OUT_*.xlsx / *_PY_REPORT.xlsx 생성되면 OK
- VBA: READY.xlsm 열고 `Alt+F8` → `TR6_SelfTest` 실행 → LOG 시트에 결과 기록되면 OK