## Tests
- [ ] test: scaffold project tree (file: src/__init__.py, name: test_scaffold_exists)
- [ ] test: basic function runs (file: src/core/app.py, name: test_app_runs)
